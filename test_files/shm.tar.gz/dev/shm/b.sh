#!/bin/bash

cd 1535065050000

export time=201808231557.57
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time

cd ..

cd 1535065080000

export time=201808231558.27
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time

cd ..

cd 1535065110000

export time=201808231558.57
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..

cd 1535065140000

export time=201808231559.27
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..

cd 1535065170000

export time=201808231559.57
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..

cd 1535065200000

export time=201808231600.27
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..

cd 1535065230000

export time=201808231600.57
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..

cd 1535065260000

export time=201808231601.27
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..

cd 1535065290000

export time=201808231601.57
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..

cd 1535065320000

export time=201808231602.27
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..

cd 1535065350000

export time=201808231602.42
find . -iname os_metrics | xargs touch -mt $time

find . -iname start | xargs touch -mt $time

find . -iname  finish | xargs touch -mt $time
cd ..
