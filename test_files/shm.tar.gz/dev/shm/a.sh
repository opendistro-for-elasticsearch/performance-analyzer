#!/bin/bash

cd 1535065050000

export oldtime=1535065050001
export time=1535065077000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"

cd ..

cd 1535065080000

export oldtime=1535065080001
export time=1535065107000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"

cd ..

cd 1535065110000

export oldtime=1535065110001
export time=1535065137000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..

cd 1535065140000

export oldtime=1535065140001
export time=1535065167000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..

cd 1535065170000

export oldtime=1535065170001
export time=1535065197000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..

cd 1535065200000

export oldtime=1535065200001
export time=1535065227000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..

cd 1535065230000

export oldtime=1535065230001
export time=1535065257000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..

cd 1535065260000

export oldtime=1535065260001
export time=1535065287000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..

cd 1535065290000

export oldtime=1535065290001
export time=1535065317000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..

cd 1535065320000

export oldtime=1535065320001
export time=1535065347000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..

cd 1535065350000

export oldtime=1535065350001
export time=1535065362000
find . -iname os_metrics | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname start | xargs sed -i -e "s/$oldtime/$time/g"

find . -iname  finish | xargs sed -i -e "s/$oldtime/$time/g"
cd ..
